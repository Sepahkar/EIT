from django.db import models
from django.contrib.auth import models as django_auth_models

class EmptyUserTeamRole(Exception):
    ...


class User(django_auth_models.AbstractUser):
    national_id = models.CharField(max_length=10, unique=True, verbose_name="کدملی", null=True)
    team_roles = models.JSONField(null=True)

    def team_manager(self, teamcode=None):
        if not self.team_roles:
            raise EmptyUserTeamRole
        
        managers_national_id = [] 
        for team_role in self.team_roles:
            if teamcode and team_role.get("TeamCode") != teamcode:
                continue
            managers_national_id.append(team_role.get("ManagerNationalCode"))
        return User.objects.filter(national_id__in=managers_national_id)
                
        
        

        
    


